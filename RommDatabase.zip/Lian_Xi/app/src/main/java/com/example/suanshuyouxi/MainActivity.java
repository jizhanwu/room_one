package com.example.suanshuyouxi;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.List;



public class MainActivity extends AppCompatActivity {
    //创建常量和变量
    Word word;
     Button button_insert,button_update,button_clere,button_delete;
    TextView textView;
    WordViewModel wordViewModel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //为ViewModel赋值
        wordViewModel = ViewModelProviders.of(this).get(WordViewModel.class);
        textView = findViewById(R.id.textView);


        //通过LiveData类，当底层数据发生变化时，通过 observe呼叫onChange方法，更新UI
        wordViewModel.cangku_Neibu_Liebiao_Neirong().observe(this, new Observer<List<Word>>() {
            @Override
            public void onChanged(List<Word> words) {
                StringBuilder text = new StringBuilder();
                //利用For循环递增显示内容，每按一次按钮，执行一次
                for(int i=0;i<words.size();i++){
                    //读取Entity实体表中最新的内容，并赋值给一个新变量"word"
                    Word word = words.get(i);
                    //为text变量赋值(text=text + ....)排版显示内容，最新ID+英文名最新内容 +中文名最新内容
                    text.append(word.getId()).append("：").append(word.getWord()).append("=").append(word.getChineseMeaning()).append("\n");
                }
                textView.setText(text.toString());

            }
        });
        //为4个按钮赋值ID
        button_insert = findViewById(R.id.button_1);
        button_clere = findViewById(R.id.button3);
        button_delete = findViewById(R.id.button4);
        button_update = findViewById(R.id.button2);


        //添加插入按钮点击事件
        button_insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //为两个列，英文名和中文列进行传递参数
                Word word1 = new Word("Hello","你好！");
                Word word2 = new Word("World","世界");
                //为Dao.Class内的接口“insertword”,传递参数
               wordViewModel.insterWords(word1,word2);
            }
        });
        //添加清除按钮点击事件
        button_clere.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wordViewModel.deleteAllWords();
            }
        });
        //添加更新按钮点击事件
        button_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //为新内容定义一个新变量，然后赋值
                Word word = new Word("HI","走你吧，快点");
                //将这个新变量设定一个要替换的ID值
                word.setId(297);
                //调取已经设定好的接口
              wordViewModel.updateWords(word);
            }
        });
        //添加删除按钮点击事件
        button_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Word word = new Word("HI","走你吧，快点");
                //将这个新变量设定一个要删除的ID值
                word.setId(210);
                //调取已经设定好的接口
               wordViewModel.deleteWords(word);
            }
        });
    }

}
    